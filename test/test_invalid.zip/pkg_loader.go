package Hephaestus

import (
	"archive/zip"
	"gopkg.in/yaml.v3"
	"io"
)

// 加载pkg包

func LoadPkg(pkg string) (*Pkg, error) {
	file, err := zip.OpenReader(pkg)
	if err != nil {
		return nil, err
	}

	defer file.Close()
	// 防止过载
	if len(file.File) < 1 || len(file.File) > MAX_FILES {
		return nil, ErrFileSize
	}
	var valid bool
	var pkgIndex int
	for index, f := range file.File {
		if f.Name == PKG_FILE {
			pkgIndex = index
			valid = true
		}
	}
	if !valid {
		return nil, ErrFileInvalid
	}

	pkgFile := file.File[pkgIndex]
	data, err := pkgFile.Open()
	if err != nil {
		return nil, err
	}
	defer data.Close()
	content, err := io.ReadAll(data)
	if err != nil {
		return nil, err
	}

	var pkgData Pkg
	if err = yaml.Unmarshal(content, &pkgData); err != nil {
		return nil, err
	}
	return &pkgData, nil
}
